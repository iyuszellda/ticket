<?php
use yii\bootstrap\ActiveForm;
use yii\helpers\Url;

$view = $this;
$this->registerJs($this->render('../../assets/script.js'),$view::POS_HEAD);
?>
<style>

    [class^='level-'], [class*=' icon-'] {
        /* ... */
    }
</style>
<div id="notif"></div>
<?php $form = ActiveForm::begin([
    'id' => 'form-role-access-management',
    'enableAjaxValidation' => true,
    'validationUrl' => ['role-access-management/validate']
]); ?>
<?php
echo $form->field($model, 'role')->dropDownList($roles,['prompt'=>'Choose Role']);
?>
<?= $htmlMenu;?>
<button class="btn btn-info" id="submit">Submit</button>
<?php ActiveForm::end(); ?>

<?php
$url = Url::to(['role-access-management/get-action-by-role']);
$urlAction = Url::to(['role-access-management/assign-action-role']);
$js = <<<JS
    
    $(".helperchecked").on('click',function(){
        classNameChecked = $(this).attr('classchecked');
        $("."+classNameChecked).prop("checked",$(this).prop("checked"));
    })
    $("#roleaccessmanagement-role").on('change',function(){
        $("input[type='checkbox']").prop("checked",false);
        $.post('$url',{role:$(this).val(),'_csrf-backend':$("input[name='_csrf-backend']").val()})
        .done(function(data) {
            data = data.data;
            if(data.data != ""){
                let helperid = [];
                data.forEach(function(val){
                    inputcheckbox = $("input[value='"+val.child+"']");
                    inputcheckbox.prop("checked",true)
                    taghelperid = inputcheckbox.attr("helperid");
                    if(undefined !== taghelperid){
                        helperid.push(inputcheckbox.attr("helperid"));
                    }
                })
                var uniqueNames = [];
                $.each(helperid, function(i, el){
                    if($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
                });
                uniqueNames.forEach(function(v){
                    rs = checkAllChecked(v);
                    $("#"+v).prop("checked",rs);
                })
            }
        });
    });

    $("form#form-role-access-management").on('beforeSubmit',function(e){
        e.preventDefault();
        $("#submit").prop('disabled',true)
        let get="";
        var obj={};
        $(".routes").each(function(){
            let name = this.value;
            if($(this).prop('checked'))
                obj['Routes['+name+']'] = true;
            else
                obj['Routes['+name+']'] = false;
        })
        obj['role'] = $("#roleaccessmanagement-role").val();
        $.post('$urlAction',obj)
        .done(function(data){
            $("#submit").prop('disabled',false);
            $("#notif").html('<div class="alert alert-success" role="alert"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>Succes<div>');
        })
        .fail(function(){
            $("#notif").html('<div class="alert alert-danger" role="alert"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>Failed<div>');
            $("#submit").prop('disabled',false);
        });;
        return false;
    })
JS;
$this->registerJs($js);

?>