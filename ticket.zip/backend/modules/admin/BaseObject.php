<?php
namespace app\modules\admin;

class BaseObject  extends \yii\base\BaseObject
{
    //put your code here
}
