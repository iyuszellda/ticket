// $(document).ready(function(){
//     console.log(url)
//     $('#form-generate-route').submit(function(e) {
//         e.preventDefault();
//         $.post(url,$(this).serialize())
//             .done(function(data){
//                 console.log(data);
//             })
//     });
// })