<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use app\modules\admin\models\Menu;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $model mdm\admin\models\Menu */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => Yii::t('rbac-admin', 'Menus'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;


?>
<div class="menu-view">
    <div>
        <h1><?= Html::encode($this->title) ?></h1>
        <p id="notif"></p>
        <p style="display: none">
            <?= Html::a(Yii::t('rbac-admin', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
            <?=
            Html::a(Yii::t('rbac-admin', 'Delete'), ['delete', 'id' => $model->id], [
                'class' => 'btn btn-danger',
                'data' => [
                    'confirm' => 'Are you sure you want to delete this item?',
                    'method' => 'post',
                ],
            ])
            ?>
        </p>
    </div>


    <?=
    DetailView::widget([
        'model' => $model,
        'attributes' => [
            'menuParent.name:text:Parent',

            'name',
            'route',
            [
                'attribute' => 'name',
                'format' => 'raw',
                'label' => 'Restrict Action',
                'value' => function($model){
                    $restrictedMenu = Menu::restrictAction($model->route);
                    $ac = "";
                    $ct = 0;
                    $ctchecked = 0;
                    foreach ($restrictedMenu AS $key => $val){
                        $action = $val['name'];
                        $label = $val['description'];
                        $restrict = $val['data'];
//                        if(strtolower($label) == "index")
//                            continue;
                        $checked = ($restrict == 1)?'checked':'';
                        if($checked != "")
                            $ctchecked++;

                        // dimunculkan khusus yang restricted 1
                        $ac .= "<label class='checkbox-inline'><input class='all' type='checkbox' $checked name='AuthItem[data][]' value='$action'>$label</label>";
                        $ct++;
                    }
                    $buttonSubmit = "";
                    if($ac != ""){
                        $checked = ($ct == $ctchecked)?'checked':'';
                        $helper = "<label class='checkbox-inline'><input  id='checkboxall' $checked type='checkbox' name='AuthItem[data][]'>All</label>";
                        $ac = "$helper$ac";
                        $buttonSubmit = "<button class='btn btn-info' id='submit'> Submit </button>";
                    }
                    return "$ac $buttonSubmit";
                },
            ],
            'order',
        ],
    ])
    ?>

</div>

<?php
$urlRestrictedAction = Url::to(['menu/restricted-action']);
$csrfToken = Yii::$app->request->csrfParam;
$csrfTokenValue = Yii::$app->request->csrfToken;
$js = <<<JS
    /**
    * 
    * @className name of class
    * @param checked
    */
    const checkedAll = (className,checked) => {
        $('input:checkbox'+className).each(function () {
            $(this).prop('checked', checked);
        });
    }
    /**
    * @className name of class
    * 
    */
    const checkAllChecked = (className) => {
        let cl = $('.'+className), length = cl.length, ct = 0;
        cl.each(function(){
            if($(this).prop("checked") === true )ct++;
        }); 
        
        if(length === ct)
            return true;
        else
            return false;
        
    }
    $(".all").on('click',function(){
        if($(this).prop("checked") === false){
            $("#checkboxall").prop("checked",false);
            let rs = checkAllChecked($(this).attr('class'))
            $("#checkboxall").prop("checked",rs);
        }
        else{
            let rs = checkAllChecked($(this).attr('class'))
            $("#checkboxall").prop("checked",rs);
        }
    })
    $("#checkboxall").on('click',function(){
        let bool = $(this).prop("checked");
        if(bool === true)
            checkedAll('.all',bool);
        else
            checkedAll('.all',bool);
    });
    
    $("#submit").on('click',function(e) {
        var data = [];
        $('.all').each(function(){
            if($(this).prop('checked')){
                data.push(this.value);
            }
        });
        
        var obj={};
        $('.all').each(function(){
            let name = this.value;
            if($(this).prop('checked'))
                obj[name] = true;
            else
                obj[name] = false;
            
        });
        obj["$csrfToken"] = "$csrfTokenValue";
        
        if(data.length > 1)
            $.post("$urlRestrictedAction",obj)
            .done(function(data){
                if(data.error_code==1)
                    $("#notif").html('<div class="alert alert-success" role="alert"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>Succes<div>');
                else
                    $("#notif").html('<div class="alert alert-danger" role="alert"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>Failed<div>');
            });
            
            
    })
JS;

$this->registerJs($js);