<?php


namespace app\modules\admin\controllers;


class MainController extends \yii\web\Controller
{

}