<?php
namespace app\modules\admin\models;

use yii\base\Model;

class RoleAccessManagement extends Model
{
    public $role;
    public $route;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['role'], 'required'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'role' => 'Roles',
        ];
    }
}