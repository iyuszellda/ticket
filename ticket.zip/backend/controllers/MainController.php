<?php


namespace backend\controllers;


class MainController extends \yii\web\Controller
{

}