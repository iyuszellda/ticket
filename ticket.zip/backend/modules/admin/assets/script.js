/**
 * @className name of class
 *
 */
const checkAllChecked = (className) => {
    let cl = $('.'+className), length = cl.length, ct = 0;
    cl.each(function(){
        console.log($(this).prop("checked"))
        if($(this).prop("checked") === true )ct++;
    });

    if(length === ct)
        return true;
    else
        return false;

}
const checkSingle = (e,id) => {
    if($(e).prop("checked") === false){
        $("#"+id).prop("checked",$(e).prop("checked"));
    }
    else{
        rs = checkAllChecked(id);
        $("#"+id).prop("checked",rs);
    }
}

const showParent = (e,parent) => {
    console.log(e.querySelector('i'))
    console.log(e.firstChild.className)
    const rows = document.querySelectorAll("tr[parent-id='"+parent+"']");
    let ic = '';
    for(var i=0;i<rows.length;i++){
        let row = rows[i];
        let display = row.style.display;
        if(display == "none"){
            ic = 'glyphicon glyphicon-chevron-down';
            row.style.display="";
        }
        else{
            row.style.display="none";
            ic = 'glyphicon glyphicon-chevron-right';
        }
    }
    e.querySelector('i').className = ic;
}

const openMenu = (parent) => {
    const rows = document.querySelectorAll("tr[parent-id='"+parent+"']");
    for(var i=0;i<rows.length;i++){
        let row = rows[i];
        let display = row.style.display;
        if(display == "none"){
            ic = 'glyphicon glyphicon-chevron-down';
            row.style.display="";
        }
        else{
            ic = 'glyphicon glyphicon-chevron-right';
            row.style.display="none";
        }
    }
}

const openCloseMenu = (e,parent,close=false) => {
    const btnClose = 'glyphicon glyphicon-chevron-right';
    const clName = e.children[0].className;
    display = (clName === btnClose)? true: false;

    const rows = document.querySelectorAll("tr[parent-id='"+parent+"']");
    let ic = '';
    for(var i=0;i<rows.length;i++){
        let row = rows[i];
        if(display === true){
            ic = 'glyphicon glyphicon-chevron-down';
            row.style.display="";
        }
        else{
            openCloseMenu(row,row.getAttribute('data-id'))
            ic = 'glyphicon glyphicon-chevron-right';
            row.style.display="none";
        }
    }
    if(e.querySelector('i') !== null)
        e.querySelector('i').className = ic;
}