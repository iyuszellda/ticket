<?php

namespace app\modules\admin\components;

/**
 * Description of UserStatus
 *
 * @author Misbahul D Munir <misbahuldmunir@gmail.com>
 * @since 2.9
 */
class UserStatus
{
    const INACTIVE = 9;
    const ACTIVE = 10;
}
