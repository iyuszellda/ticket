<?php


namespace app\modules\admin\controllers;

use app\modules\admin\components\Helper;
use app\modules\admin\components\MenuHelper;
use app\modules\admin\models\searchs\AuthItem as AuthItemSearch;
use Yii;
use app\modules\admin\models\AuthItem;
use app\modules\admin\models\RoleAccessManagement;
use yii\widgets\ActiveForm;
use yii\web\Response;
class RoleAccessManagementController extends \yii\web\Controller
{
    public $number;
    public function actionIndex()
    {
        $searchModel = new AuthItemSearch(['type' => 1]);
        $dataProvider = $searchModel->search(Yii::$app->request->getQueryParams());
        $roles = [];
        $model = new RoleAccessManagement;
        foreach ($dataProvider->allModels AS $key => $val){
            $roles[$val->name] = $val->name;
        }
        $htmlMenu = $this->getMenu();
        return $this->render('index', ['htmlMenu' => $htmlMenu,'roles' => $roles,'model'=>$model]);
    }

    public function tab($number)
    {
        $tab = "";
        for ($i = 0; $i < $number; $i++) {
            $tab .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        }
        return $tab;
    }

    public function getMenu()
    {
        $menus = MenuHelper::getAssignedMenu(Yii::$app->user->id);

        $displayMenu = $this->recursiveMenu($menus,1);
        $displayMenu = "<table class='table'><tr><td>Menu</td><td>Action</td></tr><tbody>$displayMenu</tbody></table>";
        return $displayMenu;
    }
    public function setRow($number){
        $this->number = $number;
    }
    public function increaseNumber(){
        $this->number++;
    }
    public function getRow(){
        return $this->number;
    }
    public function recursiveMenu($menus, $parent = 1, $tabLevel=0)
    {
        $tr = "";
        $this->setRow($parent);
        $parent = $parent-1;
        $number = $this->getRow();
        foreach ($menus as $key => $menu) {
            $label = $menu['label'];
            $url = $menu['url'];
            $colaction = "";
            if (is_array($url)) {
                $pos = strrpos($url[0],'/',1);
                $route = substr($url[0],0,$pos);
                $data = AuthItem::getAction($route);
                $classNameGenerate = '';
                $unique = uniqid();
                foreach ($data as $k => $ac) {
                    $rt = $ac['name'];
                    $lb = $ac['description'];
                    $restrict = $ac['data'];

                    if($restrict == null)
                        continue;
                    $colaction .= "<label class='checkbox-inline'><input helperid='$unique' type='checkbox' class='routes $unique' name='routes[]' value='$rt' onclick='checkSingle(this,\"$unique\")'>$lb</label>";
                }
                if($colaction != ""){
                    $helperall = "<label class='checkbox-inline'><input type='checkbox' id='$unique' class='helperchecked' classchecked='$unique' value>All</label>";
                    $colaction = $helperall.$colaction;
                }
            }
            $haschild = isset($menu['items']) ? true : false;
            $icon = ($haschild === true) ? "<i class='glyphicon glyphicon-chevron-right'></i>&nbsp;": $this->tab(1);
            $tab = $this->tab($tabLevel);
            $display = ($parent===0)?'cursor:pointer':'display:none;cursor:pointer';
            $event = "";
            if($haschild === true)
                $event = "onclick='openCloseMenu(this,\"{$this->getRow()}\")'";

            $tr .= "<tr style='$display' data-id='{$this->getRow()}' parent-id='$parent'>";
            $tr .= "<td class='level-$parent' $event>$tab$icon $label</td><td>$colaction</td></tr>";

            if ($haschild) {
                $this->increaseNumber();
                $tabLevelChild = $tabLevel+1;
                $tr .= $this->recursiveMenu($menu['items'], $this->getRow(),$tabLevelChild);
            }
            else
                $this->increaseNumber();

            $number++;
        }
        return $tr;
    }
    public function actionGetActionByRole(){
        $post = Yii::$app->request->post();
        $role = $post['role'];
        $query = "SELECT `child` FROM `auth_item_child` WHERE `parent` = :role";
        $connection = Yii::$app->db;
        $command = $connection->createCommand($query);
        $command->bindValue(':role',$role);
        $data = $command->queryAll();
        $response = Yii::$app->response;
        $response->format = \yii\web\Response::FORMAT_JSON;
        $response->data = ['error_code' => 1, 'error_desc' =>'Success','data' => $data];
    }
    public function actionAssignActionRole(){
        if(Yii::$app->request->post()){
            $postdata = Yii::$app->request->post();
            $connection = Yii::$app->db;

            $role = $postdata['role'];
            unset($postdata['role']);

            foreach ($postdata['Routes'] AS $key => $val){
                if($val == "true"){
                    $query = "INSERT IGNORE INTO  `auth_item_child` (`parent`, `child`) VALUES (:parent,:child)";
                    $command = $connection->createCommand($query);
                    $command->bindValue(":child",$key);
                    $command->bindValue(":parent",$role);
                    $command->execute();
                }
                else{
                    $query = "DELETE FROM `auth_item_child` WHERE `parent`=:parent AND `child`=:child";
                    $command = $connection->createCommand($query);
                    $command->bindValue(":child",$key);
                    $command->bindValue(":parent",$role);
                    $command->execute();
                }
            }
            Helper::invalidate();
            $response = Yii::$app->response;
            $response->format = \yii\web\Response::FORMAT_JSON;
            $response->data = ['error_code' => 1, 'error_desc' => 'Success'];
        }
    }
    /**
     * Validation form
     * @return array
     */
    public function actionValidate(){
        $model = new RoleAccessManagement;
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
    }
}