<?php


namespace app\modules\admin\controllers;


use app\modules\admin\models\searchs\AuthItem;
use app\modules\admin\models\GeneratorRoutes;
use app\modules\admin\components\Configs;
use app\modules\admin\components\Helper;
use yii\filters\VerbFilter;
use Yii;
use yii\rbac\Item;
use yii\web\NotFoundHttpException;
use yii\web\Response;
use yii\widgets\ActiveForm;
class RouteController extends MainController
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'assign' => ['post'],
                    'remove' => ['post'],
                    'refresh' => ['post'],
                ],
            ],
        ];
    }
    public function actionIndex(){
        $searchModel = new AuthItem;
        $dataProvider = $searchModel->search(Yii::$app->request->getQueryParams());

        return $this->render('index', [
            'dataProvider' => $dataProvider,
            'searchModel' => $searchModel,
        ]);
    }

    /**
     * Format for insert table auth_item
     * @param $routes
     * @return array
     */
    public function formatInsertAuthItem($routes){
        $data = [];

        foreach ($routes AS $key => $val){
            $find = ["-","/"];
            $replace = ["",""];
            $actionName = ucwords(str_replace($find,$replace,strrchr($val, '/')));
            $data[] = ["$val",$actionName ,2];
        }
        return $data;
    }
    public function actionUpdate($id){
        $model = $this->findModel($id);

        if($model->load(Yii::$app->request->post()) && $model->validate()){
            if($model->save()){
                return $this->redirect(['view', 'id' => $model->name]);
            }
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }
    public function actionCreate(){
        $model = new GeneratorRoutes;

        if ($model->load(Yii::$app->request->post())) {
            $routes = $this->generateRoute($model->name);

            $data = $this->formatInsertAuthItem($routes);
            $class = $model->name;

            if(count($data)>0){
                $model->saved($data);
            }

            return $this->redirect(['index']);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Generate Route
     * @param $class name of class
     * @return array
     */
    public function generateRoute($class){
        $routes = [];
        $c = get_class_methods($class);

        $find = ["backend\controllers\\", "app\controllers\\", "frontend\controllers\\","Controller","\\"];
        $replace   = ["", "", "","","/"];

        $routeclass = str_replace($find, $replace, $class);
        $routeclass = preg_replace('/(?<!\ )[A-Z]/', '-$0', strtolower($routeclass));
        foreach ($c AS $key => $val){
            if (preg_match("/^action+[A-Z]/", $val)) {
                $route = str_replace("action","",$val);
                $route = preg_replace('/(?<!\ )[A-Z]/', '-$0', lcfirst($route));
                $route = strtolower($route);
                $routes[] = "/$routeclass/$route";
            }
        }
        return $routes;
    }

    /**
     * Validation form
     * @return array
     */
    public function actionValidate(){
        $model = new GeneratorRoutes;
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
    }

    /**
     * Displays a single AuthItem model.
     * @param  string $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);

        return $this->render('view', ['model' => $model]);
    }

    protected function findModel($id)
    {
        $auth = Configs::authManager();
        $item = $this->type === Item::TYPE_ROLE ? $auth->getRole($id) : $auth->getPermission($id);
        if ($item) {
            return new \app\modules\admin\models\AuthItem($item);
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    /**
     * @inheritdoc
     */
    public function getType()
    {
        return Item::TYPE_PERMISSION;
    }

    public function actionDelete($id){
        $model = $this->findModel($id);
        Configs::authManager()->remove($model->item);
        Helper::invalidate();
        return $this->redirect(['index']);
    }
}