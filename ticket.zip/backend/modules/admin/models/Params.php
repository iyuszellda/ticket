<?php

namespace app\modules\admin\models;

use Yii;

/**
 * This is the model class for table "{{%tbl_params}}".
 *
 * @property int $tp_id
 * @property string $tp_name
 * @property string $tp_value
 */
class Params extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%tbl_params}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['tp_name', 'tp_value'], 'required'],
            [['tp_name', 'tp_value'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'tp_id' => 'Tp ID',
            'tp_name' => 'Tp Name',
            'tp_value' => 'Tp Value',
        ];
    }
}
