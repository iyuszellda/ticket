<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model mdm\admin\models\Menu */

$this->title = Yii::t('rbac-admin', 'Update Route');
$this->params['breadcrumbs'][] = ['label' => Yii::t('rbac-admin', 'Menus'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
//echo "<pre>";
//print_r($model);
//echo "</pre>";
//die();
?>
<div class="menu-create">
    <h1><?= Html::encode($this->title) ?></h1>
    <div class="menu-form">
        <?php $form = ActiveForm::begin([
            'id' => 'form-generate-route',
        ]); ?>
        <div class="row">
            <div class="col-sm-6">
                <?= $form->field($model, 'name')->textInput(['maxlength' => 255]) ?>
            </div>
            <div class="col-sm-6">
                <?= $form->field($model, 'description')->textInput(['maxlength' => 255]) ?>
            </div>
        </div>

        <div class="form-group">
            <?=
            Html::submitButton($model->isNewRecord ? Yii::t('rbac-admin', 'Update') : Yii::t('rbac-admin', 'Update'), ['class' => $model->isNewRecord
                ? 'btn btn-success' : 'btn btn-primary'])
            ?>
        </div>
        <?php ActiveForm::end(); ?>
    </div>


</div>
