<?php
namespace app\modules\admin\models;

use app\modules\admin\components\Configs;
use yii\base\Model;
use yii\web\NotFoundHttpException;
use Yii;
class GeneratorRoutes extends Model {
    public $name;
    public $description;
    public $isNewRecord=true;
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name'], 'required'],
            [['name','description'], 'string', 'max' => 255],
            ['name', 'match', 'pattern' => '/^[\w\\\\]*Controller$/', 'message' => 'Only word characters and backslashes are allowed, and the class name must end with "Controller".'],
            ['name', 'validateClass'],
        ];
    }

    /**
     * An inline validator that checks if the attribute value refers to an existing class name.
     * If the `extends` option is specified, it will also check if the class is a child class
     * of the class represented by the `extends` option.
     * @param string $attribute the attribute being validated
     * @param array $params the validation options
     */
    public function validateClass($attribute, $params)
    {
        $class = $this->$attribute;
        try {
            if (class_exists($class)) {
                if (isset($params['extends'])) {
                    if (ltrim($class, '\\') !== ltrim($params['extends'], '\\') && !is_subclass_of($class, $params['extends'])) {
                        $this->addError($attribute, "'$class' must extend from {$params['extends']} or its child class.");
                    }
                }
            } else {
                $this->addError($attribute, "Class '$class' does not exist or has syntax error.");
            }
        } catch (\Exception $e) {
            $this->addError($attribute, "Class '$class' does not exist or has syntax error.");
        }
    }

    public function validateRoute($attribute, $params){

    }

    public function saved($data){
        $connection = Yii::$app->db;
        $authManager = Configs::authManager();
        $table = $authManager->itemTable;
        $command = $connection->createCommand()->batchInsert($table, ['name', 'description','type'], $data);
        $sql = $command->getRawSql();
        $sql .= ' ON DUPLICATE KEY UPDATE `name`=`name`';
        $command->setRawSql($sql);
        $command->execute();
    }


    public static function findModel($id){
        $authManager = Configs::authManager();
        $table = $authManager->itemTable;
        $query = "SELECT `name`, `description` FROM $table WHERE `name`=:id AND `type`=:type";
        $connection = $authManager->db;
        $command = $connection->createCommand($query)->bindValues([":id"=>$id,':type'=>2]);
        $rs = $command->queryOne();
        if($rs == ""){
            throw new NotFoundHttpException('The requested page does not exist.');
        }
        return $rs;
    }
}