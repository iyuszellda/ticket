<?php

namespace app\modules\admin\models;

use app\modules\admin\components\UserStatus;
use Yii;
use yii\base\NotSupportedException;
use yii\web\IdentityInterface;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%tbl_user_additional}}".
 *
 * @property string|null $tua_phone_number
 * @property int $tua_user_id
 *
 * @property User $tuaUser
 */
class UserAdditional extends ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%tbl_user_additional}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['tua_user_id'], 'required'],
            [['tua_user_id'], 'integer'],
            [['tua_phone_number'], 'string', 'max' => 13],
            [['tua_user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['tua_user_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'tua_phone_number' => 'Tua Phone Number',
            'tua_user_id' => 'Tua User ID',
        ];
    }

    /**
     * Gets query for [[TuaUser]].
     *
     * @return \yii\db\ActiveQuery
     */
//    public function getTuaUser()
//    {
//        return $this->hasOne(User::className(), ['id' => 'tua_user_id']);
//    }

//    /**
//     * @inheritdoc
//     */
//    public static function findIdentityByAccessToken($token, $type = null)
//    {
//        throw new NotSupportedException('"findIdentityByAccessToken" is not implemented.');
//    }
//
//    /**
//     * @inheritdoc
//     */
//    public function getId()
//    {
//        return $this->getPrimaryKey();
//    }
//
//
//    /**
//     * @inheritdoc
//     */
//    public function getAuthKey()
//    {
//        return $this->auth_key;
//    }
//
//    /**
//     * @inheritdoc
//     */
//    public function validateAuthKey($authKey)
//    {
//        return $this->getAuthKey() === $authKey;
//    }
//    /**
//     * @inheritdoc
//     */
//    public static function findIdentity($id)
//    {
//        return static::findOne(['id' => $id, 'status' => UserStatus::ACTIVE]);
//    }
}
