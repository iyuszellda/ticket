<?php
namespace app\modules\admin\components;

class FileCache
{

}